"use client";

import { useState, useCallback } from "react";
import { useAccount, useWriteContract } from "wagmi";

import MeshBg from "@/components/MeshBg";
import Header from "@/components/Header";
import SwipeCard from "@/components/SwipeCard";
import BottomActions from "@/components/BottomActions";
import MatchModal from "@/components/MatchModal";
import HeartParticles from "@/components/HeartParticles";
import { MOCK_PROFILES, type Profile } from "@/lib/profiles";
import { CONTRACTS, bobTestnet } from "@/lib/wagmi";
import { BITMATCH_ABI } from "@/lib/abi";

export default function HomePage() {
  const { address, isConnected, chainId } = useAccount();
  const { writeContract } = useWriteContract();

  const [profiles] = useState<Profile[]>([...MOCK_PROFILES]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [heartBalance, setHeartBalance] = useState(0);
  const [matchCount, setMatchCount] = useState(0);
  const [matchProfile, setMatchProfile] = useState<Profile | null>(null);
  const [particles, setParticles] = useState(false);
  const [notif, setNotif] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("feed");

  const current = profiles[currentIndex];
  const next = profiles[currentIndex + 1];
  const afterNext = profiles[currentIndex + 2];

  const contracts = chainId ? CONTRACTS[chainId as keyof typeof CONTRACTS] : null;

  const showNotif = (msg: string) => {
    setNotif(msg);
    setTimeout(() => setNotif(null), 2200);
  };

  const handleHeart = useCallback((profile: Profile = current) => {
    if (!profile) return;

    // Call on-chain if wallet connected
    if (isConnected && contracts && address) {
      writeContract({
        address: contracts.BitMatch as `0x${string}`,
        abi: BITMATCH_ABI,
        functionName: "sendHeart",
        args: [profile.address as `0x${string}`],
      });
    }

    // Optimistic UI — ~45% match rate for demo
    const isMatch = Math.random() > 0.55;
    if (isMatch) {
      setHeartBalance((h) => h + 11); // +1 for like + 10 for match
      setMatchCount((m) => m + 1);
      setParticles(true);
      setTimeout(() => setMatchProfile(profile), 350);
    } else {
      setHeartBalance((h) => h + 1);
      showNotif("❤️ +1 $HEART mined!");
    }

    setCurrentIndex((i) => i + 1);
  }, [current, isConnected, contracts, address, writeContract]);

  const handlePass = useCallback(() => {
    setCurrentIndex((i) => i + 1);
  }, []);

  const handleSuperHeart = useCallback(() => {
    if (heartBalance < 1) return;
    setHeartBalance((h) => h - 1);
    handleHeart();
    showNotif("⚡ Super Heart sent!");
  }, [heartBalance, handleHeart]);

  const handleSwipe = useCallback((direction: "left" | "right", profile: Profile) => {
    if (direction === "right") handleHeart(profile);
    else handlePass();
  }, [handleHeart, handlePass]);

  return (
    <div style={{ minHeight: "100dvh", display: "flex", flexDirection: "column", maxWidth: 430, margin: "0 auto", position: "relative", zIndex: 1 }}>

      {/* Animated mesh background — color follows current profile */}
      <MeshBg color={current?.glowColor} />

      {/* Particles */}
      <HeartParticles active={particles} onComplete={() => setParticles(false)} />

      {/* Match modal */}
      {matchProfile && (
        <MatchModal profile={matchProfile} heartBalance={heartBalance} onClose={() => setMatchProfile(null)} />
      )}

      {/* Notification toast */}
      {notif && (
        <div style={{
          position: "fixed", bottom: 130, left: "50%",
          background: "rgba(10,10,15,0.95)", backdropFilter: "blur(20px)",
          border: "1px solid rgba(255,255,255,0.15)", borderRadius: 24,
          padding: "10px 22px", zIndex: 500,
          fontFamily: "'Space Mono', monospace", fontSize: 12, color: "#fff", fontWeight: 700,
          animation: "notifPop 2.2s ease forwards", whiteSpace: "nowrap",
          boxShadow: "0 8px 32px rgba(0,0,0,0.5)",
        }}>{notif}</div>
      )}

      {/* Header */}
      <Header heartBalance={heartBalance} matchCount={matchCount} />

      {/* Connect wallet banner */}
      {!isConnected && (
        <div style={{
          margin: "12px 22px 0", padding: "10px 16px",
          background: "rgba(255,107,0,0.08)", border: "1px solid rgba(255,107,0,0.25)",
          borderRadius: 14, fontFamily: "'Space Mono', monospace",
          fontSize: 10, color: "rgba(255,107,0,0.9)", animation: "pulse 2.5s ease infinite",
        }}>
          ⚡ Connect wallet to save matches on-chain · BOB L2
        </div>
      )}

      {/* Card stack */}
      <div style={{
        flex: 1, display: "flex", alignItems: "center", justifyContent: "center",
        padding: "20px 20px 0", position: "relative", minHeight: 520,
      }}>
        {current ? (
          <div style={{ position: "relative", width: "100%", maxWidth: 370, height: 560 }}>
            {afterNext && <SwipeCard profile={afterNext} onSwipe={() => {}} isTop={false} stackOffset={24} />}
            {next && <SwipeCard profile={next} onSwipe={() => {}} isTop={false} stackOffset={12} />}
            <SwipeCard profile={current} onSwipe={handleSwipe} isTop={true} />
          </div>
        ) : (
          /* Empty state */
          <div style={{ textAlign: "center", padding: 40 }}>
            <div style={{ fontSize: 64, marginBottom: 16 }}>₿</div>
            <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 24, fontWeight: 800, color: "#fff", marginBottom: 8 }}>
              All caught up!
            </div>
            <p style={{ fontFamily: "'DM Serif Display', serif", fontSize: 14, color: "rgba(255,255,255,0.4)", lineHeight: 1.6, marginBottom: 28 }}>
              The market is in accumulation mode.<br />Check back soon.
            </p>
            <button onClick={() => setCurrentIndex(0)} style={{
              padding: "13px 30px",
              background: "linear-gradient(135deg, #FF6B00, #FF0080)",
              border: "none", borderRadius: 20,
              fontFamily: "'Space Mono', monospace", fontSize: 11, fontWeight: 700,
              color: "#fff", cursor: "pointer",
              boxShadow: "0 4px 24px rgba(255,107,0,0.5)",
            }}>Reload feed</button>
          </div>
        )}
      </div>

      {/* Action buttons */}
      {current && (
        <BottomActions
          profile={current}
          onPass={handlePass}
          onHeart={() => handleHeart()}
          onSuperHeart={handleSuperHeart}
          canSuperHeart={heartBalance >= 1}
        />
      )}

      {/* Nav bar */}
      <div style={{
        display: "flex", justifyContent: "space-around",
        borderTop: "1px solid rgba(255,255,255,0.07)",
        padding: "12px 0 24px",
        background: "rgba(10,10,15,0.8)", backdropFilter: "blur(20px)",
      }}>
        {[
          { key: "feed", label: "Feed", icon: "🔥" },
          { key: "matches", label: "Matches", icon: "💘" },
          { key: "profile", label: "Profile", icon: "₿" },
          { key: "govern", label: "Govern", icon: "🗳️" },
        ].map((item) => (
          <button key={item.key} onClick={() => setActiveTab(item.key)} style={{
            display: "flex", flexDirection: "column", alignItems: "center", gap: 4,
            background: "none", border: "none", cursor: "pointer",
            fontFamily: "'Space Mono', monospace", fontSize: 9,
            color: activeTab === item.key ? "#fff" : "rgba(255,255,255,0.3)",
            letterSpacing: 0.5, transition: "all 0.2s",
          }}>
            <span style={{
              fontSize: 20, display: "block", transition: "all 0.2s",
              filter: activeTab === item.key ? "drop-shadow(0 0 6px rgba(255,107,0,0.8))" : "none",
              transform: activeTab === item.key ? "scale(1.15)" : "scale(1)",
            }}>{item.icon}</span>
            {item.label}
          </button>
        ))}
      </div>
    </div>
  );
}
