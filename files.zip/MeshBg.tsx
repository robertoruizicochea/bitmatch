"use client";

interface MeshBgProps {
  color?: string;
}

export default function MeshBg({ color = "#F97316" }: MeshBgProps) {
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 0, overflow: "hidden", pointerEvents: "none" }}>
      <div style={{ position: "absolute", inset: 0, background: "#0A0A0F" }} />

      {/* Animated color blob — follows current profile color */}
      <div style={{
        position: "absolute", width: 500, height: 500, borderRadius: "50%",
        filter: "blur(120px)", opacity: 0.25, background: color,
        top: "-100px", left: "-100px",
        animation: "blob1 8s ease-in-out infinite",
        transition: "background 0.8s ease",
      }} />

      {/* Pink blob */}
      <div style={{
        position: "absolute", width: 400, height: 400, borderRadius: "50%",
        filter: "blur(100px)", opacity: 0.18, background: "#EC4899",
        bottom: "100px", right: "-80px",
        animation: "blob2 10s ease-in-out infinite",
      }} />

      {/* Purple blob */}
      <div style={{
        position: "absolute", width: 350, height: 350, borderRadius: "50%",
        filter: "blur(90px)", opacity: 0.14, background: "#7C3AED",
        top: "40%", left: "30%",
        animation: "blob3 12s ease-in-out infinite",
      }} />
    </div>
  );
}
