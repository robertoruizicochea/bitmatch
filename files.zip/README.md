# 💘 BitMatch — Tinder on Bitcoin

> Swipe right. Match. Mine $HEART. Built on BOB L2.

**BitMatch** is Tinder, but on Bitcoin. Swipe right, send a ❤️, and when it's mutual — boom, you both mine **$HEART** tokens on the spot. Your profile photo is a real Bitcoin Ordinal inscription, so your face literally lives on the blockchain. The more you match, the more you earn. Spend **$HEART** to boost your profile, send Super Hearts, or unlock features.

**Swipe. Match. Mine. 🧡**

---

## Monorepo Structure

```
bitmatch/
├── contracts/              # Solidity smart contracts (Hardhat)
│   ├── contracts/
│   │   ├── HeartToken.sol  # $HEART OP-20 governance token
│   │   └── BitMatch.sol    # Core swipe/match/boost logic
│   ├── scripts/deploy.ts   # Deploy to BOB L2
│   └── test/               # Full test suite
│
└── frontend/               # Next.js 14 app
    └── src/
        ├── app/            # Pages + layout (Wagmi provider)
        ├── components/     # SwipeCard, MatchModal, Header, etc.
        └── lib/            # ABIs, wagmi config, profiles
```

---

## Quick Start

```bash
# Install all workspaces
npm install

# Run frontend dev server
npm run dev

# Compile contracts
npm run compile

# Run contract tests
npm run test

# Deploy to BOB Testnet
npm run deploy:testnet
```

---

## How $HEART Works

```
You swipe right          →  +1 $HEART minted to you
Mutual match 💘          →  +10 $HEART to both users
Boost your profile       →  spend 5 $HEART for 24h visibility
Send a Super Heart ⚡    →  spend 1 $HEART for priority notification
```

---

## Smart Contracts

| Contract | Description |
|----------|-------------|
| `HeartToken.sol` | OP-20 token. Max supply 100M. Only BitMatch can mint. |
| `BitMatch.sol` | Profile registry, like system, auto match detection, boost. |

---

## Frontend Stack

| Layer | Tech |
|-------|------|
| Framework | Next.js 14 (App Router) |
| Wallet | Wagmi v2 + MetaMask |
| Chain calls | Viem |
| Network | BOB L2 (Chain ID 111 testnet / 60808 mainnet) |

---

## BOB Testnet Setup

Add to MetaMask:

| | |
|-|-|
| RPC | `https://testnet.rpc.gobob.xyz` |
| Chain ID | `111` |
| Explorer | https://testnet-explorer.gobob.xyz |
| Faucet | https://faucet.gobob.xyz |

---

## CI

GitHub Actions runs on every push:
- ✅ Compile contracts
- ✅ Run full test suite
- ✅ Build frontend

---

## Roadmap

- [x] $HEART token (OP-20)
- [x] Match logic on-chain
- [x] Swipe UI with animations
- [x] Wallet connect + on-chain hearts
- [ ] Ordinals indexer (real inscription images)
- [ ] Lightning tips between matches
- [ ] On-chain messaging (XMTP)
- [ ] $HEART governance (Snapshot)
- [ ] Match DAOs

---

> *"Not your keys, not your matches."*
