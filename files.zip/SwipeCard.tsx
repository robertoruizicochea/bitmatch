"use client";

import { useRef, useState } from "react";
import type { Profile } from "@/lib/profiles";

interface SwipeCardProps {
  profile: Profile;
  onSwipe: (direction: "left" | "right", profile: Profile) => void;
  isTop: boolean;
  stackOffset?: number;
}

export default function SwipeCard({ profile, onSwipe, isTop, stackOffset = 0 }: SwipeCardProps) {
  const startX = useRef(0);
  const currentX = useRef(0);
  const isDragging = useRef(false);
  const [drag, setDrag] = useState(0);
  const [dir, setDir] = useState<"left" | "right" | null>(null);

  const onStart = (x: number) => {
    if (!isTop) return;
    isDragging.current = true;
    startX.current = x;
  };
  const onMove = (x: number) => {
    if (!isDragging.current) return;
    const d = x - startX.current;
    currentX.current = d;
    setDrag(d);
    setDir(d > 35 ? "right" : d < -35 ? "left" : null);
  };
  const onEnd = () => {
    if (!isDragging.current) return;
    isDragging.current = false;
    if (currentX.current > 110) onSwipe("right", profile);
    else if (currentX.current < -110) onSwipe("left", profile);
    setDrag(0);
    setDir(null);
    currentX.current = 0;
  };

  return (
    <div
      onMouseDown={(e) => onStart(e.clientX)}
      onMouseMove={(e) => onMove(e.clientX)}
      onMouseUp={onEnd}
      onMouseLeave={onEnd}
      onTouchStart={(e) => onStart(e.touches[0].clientX)}
      onTouchMove={(e) => onMove(e.touches[0].clientX)}
      onTouchEnd={onEnd}
      style={{
        position: "absolute",
        width: "100%",
        maxWidth: 370,
        cursor: isTop ? "grab" : "default",
        transform: `translateX(${drag}px) rotate(${drag * 0.07}deg) translateY(${stackOffset}px) scale(${isTop ? 1 : 0.94 - stackOffset * 0.001})`,
        transition: isDragging.current ? "none" : "transform 0.45s cubic-bezier(0.175,0.885,0.32,1.275)",
        zIndex: isTop ? 10 : 5 - Math.abs(stackOffset),
        userSelect: "none",
        touchAction: "none",
      }}
    >
      {/* HEART indicator */}
      {dir === "right" && (
        <div style={{
          position: "absolute", top: 28, left: 20, zIndex: 20,
          background: profile.cardGrad, borderRadius: 14, padding: "10px 22px",
          transform: "rotate(-12deg)",
          fontFamily: "'Syne', sans-serif", fontSize: 26, fontWeight: 900,
          color: "white", letterSpacing: 3,
          boxShadow: `0 0 30px ${profile.glowColor}88`,
          border: "2px solid rgba(255,255,255,0.3)",
        }}>❤️ HEART</div>
      )}
      {/* NOPE indicator */}
      {dir === "left" && (
        <div style={{
          position: "absolute", top: 28, right: 20, zIndex: 20,
          background: "rgba(20,20,30,0.95)", borderRadius: 14, padding: "10px 22px",
          transform: "rotate(12deg)",
          fontFamily: "'Syne', sans-serif", fontSize: 26, fontWeight: 900,
          color: "#666", letterSpacing: 3, border: "2px solid #333",
        }}>✕ NOPE</div>
      )}

      <div style={{
        borderRadius: 32, overflow: "hidden", background: "#12121A",
        border: `1px solid ${profile.glowColor}44`,
        boxShadow: isTop
          ? `0 0 0 1px ${profile.glowColor}33, 0 24px 80px rgba(0,0,0,0.7), 0 0 60px ${profile.glowColor}22`
          : "0 8px 40px rgba(0,0,0,0.6)",
      }}>
        {/* Gradient image area */}
        <div style={{
          height: 330, position: "relative", overflow: "hidden",
          background: profile.cardGrad,
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          {/* Shiny overlay */}
          <div style={{
            position: "absolute", inset: 0,
            background: "linear-gradient(135deg, rgba(255,255,255,0.15) 0%, transparent 50%, rgba(0,0,0,0.3) 100%)",
          }} />

          {/* Avatar */}
          <div style={{
            width: 150, height: 150, borderRadius: "50%",
            background: "rgba(0,0,0,0.3)", backdropFilter: "blur(10px)",
            border: "3px solid rgba(255,255,255,0.3)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 70,
            boxShadow: "0 0 40px rgba(0,0,0,0.5), inset 0 0 20px rgba(255,255,255,0.1)",
            zIndex: 2,
          }}>{profile.emoji}</div>

          {profile.boosted && (
            <div style={{
              position: "absolute", top: 16, right: 16, zIndex: 3,
              background: "rgba(0,0,0,0.6)", backdropFilter: "blur(10px)",
              borderRadius: 20, padding: "5px 14px",
              fontFamily: "'Space Mono', monospace",
              fontSize: 10, fontWeight: 700, color: "#FFD700",
              letterSpacing: 1.5, border: "1px solid rgba(255,215,0,0.4)",
            }}>⚡ BOOSTED</div>
          )}

          {/* Stats */}
          <div style={{ position: "absolute", top: 16, left: 16, zIndex: 3, display: "flex", flexDirection: "column", gap: 4 }}>
            <div style={{
              background: "rgba(0,0,0,0.6)", backdropFilter: "blur(10px)",
              borderRadius: 12, padding: "3px 10px",
              fontFamily: "'Space Mono', monospace", fontSize: 10, color: "rgba(255,255,255,0.8)",
            }}>❤️ {profile.hearts}</div>
            <div style={{
              background: "rgba(0,0,0,0.6)", backdropFilter: "blur(10px)",
              borderRadius: 12, padding: "3px 10px",
              fontFamily: "'Space Mono', monospace", fontSize: 10, color: "rgba(255,255,255,0.8)",
            }}>💘 {profile.matches}</div>
          </div>

          {/* Inscription */}
          <div style={{
            position: "absolute", bottom: 10, left: 12, right: 12, zIndex: 3,
            fontFamily: "'Space Mono', monospace", fontSize: 8, color: "rgba(255,255,255,0.3)",
            overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
          }}>₿ {profile.inscription}</div>

          <div style={{
            position: "absolute", bottom: 0, left: 0, right: 0, height: "55%",
            background: "linear-gradient(to top, #12121A, transparent)", zIndex: 1,
          }} />
        </div>

        {/* Info */}
        <div style={{ padding: "18px 22px 22px", background: "linear-gradient(180deg, #12121A 0%, #0E0E16 100%)" }}>
          <div style={{ marginBottom: 8 }}>
            <div style={{
              fontFamily: "'Syne', sans-serif", fontSize: 26, fontWeight: 800, color: "#fff",
              lineHeight: 1.1, textShadow: `0 0 30px ${profile.glowColor}66`,
            }}>{profile.name}</div>
            <div style={{
              fontFamily: "'Space Mono', monospace", fontSize: 11, marginTop: 4,
              background: profile.cardGrad, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}>📍 {profile.location} · {profile.age}</div>
          </div>

          <p style={{
            fontFamily: "'DM Serif Display', serif", fontSize: 13,
            color: "rgba(255,255,255,0.65)", lineHeight: 1.65,
            margin: "10px 0 14px", minHeight: 42,
          }}>{profile.bio}</p>

          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {profile.tags.map((tag) => (
              <span key={tag} style={{
                fontFamily: "'Space Mono', monospace", fontSize: 9, color: profile.accentColor,
                border: `1px solid ${profile.glowColor}55`, borderRadius: 20, padding: "4px 12px",
                background: `${profile.glowColor}18`, letterSpacing: 0.5,
                boxShadow: `0 0 10px ${profile.glowColor}22`,
              }}>#{tag}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
